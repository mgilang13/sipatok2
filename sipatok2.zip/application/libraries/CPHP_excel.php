<?php
 
class CPHP_excel {
	
	function __construct() {
		require_once APPPATH.'/libraries/PHPExcel.php';
	}

}

?>